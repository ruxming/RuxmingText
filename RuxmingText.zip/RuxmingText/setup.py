from setuptools import setup

setup(name='RuxmingText',
      version='0.1',
      description='Process Text in the world',
      url='https://github.com/ruxming/RuxmingText',
      author='Ruxming',
      author_email='ruxming@qq.com',
      license='MIT',
      packages=['RuxmingText'],
      zip_safe=False)